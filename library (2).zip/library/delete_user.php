<?php
require_once("inc/conn.php");
require_once("inc/utils.php");

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: manage_users.php?msg=Invalid user ID");
    exit;
}

$user_id = intval($_GET['id']); 

session_start();
if (isset($_SESSION['user']['id']) && $_SESSION['user']['id'] == $user_id) {
    header("Location: manage_users.php?msg=You cannot delete your own account");
    exit;
}

$sql = "DELETE FROM users WHERE user_id = $user_id";
saveData($sql);

header("Location: manage_users.php?msg=User deleted successfully");
exit;
?>
