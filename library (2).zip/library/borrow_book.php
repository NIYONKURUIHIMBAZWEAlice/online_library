<?php
 include "inc/header.php";
require_once("inc/conn.php");
require_once("inc/utils.php");


if (!isset($_SESSION['user']['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user']['user_id'];
$book_id = $_GET['book_id'] ?? null;

if (!$book_id) {
    die("Invalid book ID.");
}

$book = getdata("SELECT * FROM book WHERE id = $book_id");
if (!$book) {
    die("Book not found.");
}
$book = $book[0];


if (isset($_POST['confirm_borrow'])) {

    $return_date = $_POST['return_date'] ?? null;

    if (!$return_date) {
        $error = "Please select a return date.";
    } elseif ($book['quantity'] <= 0) {
        $error = "Sorry, this book is currently unavailable.";
    } else {
        $borrow_date = date('Y-m-d H:i:s');
        $sql = "INSERT INTO borrowed(user_id, book_id, date_borrowed, date_to_return) VALUES ('$user_id', '$book_id', '$borrow_date', '$return_date')";
        saveData($sql);

        header("Location: library.php?msg=Book borrowed successfully");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm Borrow</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Confirm Borrow</h2>
    <?php if (!empty($error)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <div class="card mb-3" style="max-width: 540px;">
        <div class="row g-0">
            <div class="col-md-4">
                <?php if (!empty($book['image'])): ?>
                    <img src="<?= htmlspecialchars($book['image']); ?>" class="img-fluid rounded-start" alt="<?= htmlspecialchars($book['title']); ?>">
                <?php else: ?>
                    <div class="d-flex align-items-center justify-content-center bg-light" style="height:100%; min-height:150px;">
                        <span class="text-muted">No Image</span>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-md-8">
                <div class="card-body">
                    <h5 class="card-title"><?= htmlspecialchars($book['title']); ?></h5>
                    <p class="card-text"><strong>Author:</strong> <?= htmlspecialchars($book['author']); ?></p>
                    <p class="card-text"><strong>Quantity Available:</strong> <?= htmlspecialchars($book['quantity']); ?></p>
                    <p class="card-text"><strong>Published Year:</strong> <?= htmlspecialchars($book['published_year']); ?></p>

                    <form method="post">
                        <div class="mb-3">
                            <label for="return_date" class="form-label">Return Date</label>
                            <input type="date" class="form-control" name="return_date" id="return_date" required min="<?= date('Y-m-d') ?>">
                        </div>
                        <button type="submit" name="confirm_borrow" class="btn btn-success" <?= $book['quantity'] <= 0 ? 'disabled' : '' ?>>
                            Confirm Borrow
                        </button>
                        <a href="library.php" class="btn btn-secondary">Cancel</a>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
