<?php
require "inc/conn.php";

$privacy = "";  

if (isset($_POST['add'])) {
    $title   = $_POST['title'];
    $author  = $_POST['author'];
    $year    = $_POST['published_year'];
    $qty     = $_POST['quantity'];
    $privacy = $_POST['privacy']; 

    $imageName = $_FILES['image']['name'];
    $tmpName   = $_FILES['image']['tmp_name'];

    $uploadFolder = "uploads/";
    if (!is_dir($uploadFolder)) {
        mkdir($uploadFolder, 0777, true);
    }

    $imagePath = $uploadFolder . time() . "_" . $imageName;
    move_uploaded_file($tmpName, $imagePath);

    $insert = "INSERT INTO book(title, author, published_year, quantity, image, privacy)
               VALUES('$title', '$author', '$year', '$qty', '$imagePath', '$privacy')";

    if ($conn->query($insert)) {
        header("Location: books.php");
        exit;
    } else {
        echo "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
    }
}
?>

<?php include "inc/header.php"; ?>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-6">

            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Add New Book</h4>
                </div>
                <div class="card-body">
                    <form method="POST" enctype="multipart/form-data">
                        
                        <div class="mb-3">
                            <label class="form-label">Book Title</label>
                            <input type="text" name="title" class="form-control" placeholder="Enter book title" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Author</label>
                            <input type="text" name="author" class="form-control" placeholder="Enter author name" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Published Year</label>
                            <input type="number" name="published_year" class="form-control" placeholder="e.g., 2025" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Quantity</label>
                            <input type="number" name="quantity" class="form-control" placeholder="Number of books" min="1" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Book Image</label>
                            <input type="file" name="image" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Privacy</label>
                            <select name="privacy" class="form-control" required>
                                <option value="public" <?= $privacy == "public" ? "selected" : "" ?>>Public</option>
                                <option value="private" <?= $privacy == "private" ? "selected" : "" ?>>Private</option>
                            </select>
                        </div>

                        <div class="d-flex justify-content-between">
                            <a href="books.php" class="btn btn-secondary">Back to Books</a>
                            <button type="submit" name="add" class="btn btn-primary">Save Book</button>
                        </div>

                    </form>
                </div>
            </div>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
