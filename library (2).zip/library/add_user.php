<?php
require_once("inc/conn.php");
require_once("inc/utils.php");
include "inc/header.php";

$error = "";
$fullname = "";
$username = "";
$role = "GUEST";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['fullname']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $role     = $_POST['role'] ?? "GUEST";

    if (empty($fullname) || empty($username) || empty($password)) {
        $error = "All fields are required.";
    } else {
    
        $existing = getdata("SELECT * FROM users WHERE username='$username'");
        if (!empty($existing)) {
            $error = "Username already exists.";
        } else {
            
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            $sql = "INSERT INTO users (fullname, username, password, role) VALUES ('$fullname', '$username', '$hashed_password', '$role')";
            saveData($sql, []);

            header("Location: manage_users.php?msg=User added successfully");
            exit;
        }
    }
}
?>

<div class="container mt-5">
    <h2>Add New User</h2>
    <a href="manage_users.php" class="btn btn-secondary mb-3">Back to Users</a>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" class="card p-4 shadow-sm">
        <div class="mb-3">
            <label class="form-label">Full Name</label>
            <input type="text" name="fullname" class="form-control" value="<?= htmlspecialchars($fullname) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($username) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Role</label>
            <select name="role" class="form-control">
                <!--<option value="GUEST" <?= $role == "GUEST" ? "selected" : "" ?>>GUEST</option>-->
                <option value="MEMBER" <?= $role == "MEMBER" ? "selected" : "" ?>>MEMBER</option>
                <!--<option value="LIBRARIAN" <?= $role == "LIBRARIAN" ? "selected" : "" ?>>LIBRARIAN</option>-->
            </select>
        </div>

        <button type="submit" class="btn btn-success">Add User</button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
