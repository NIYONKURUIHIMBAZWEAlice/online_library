<?php include "inc/header.php"; ?>
<?php
require_once("inc/utils.php");
require "inc/conn.php";
// die($_SESSION["user"]["role"]);
// Check if user is logged in and has permission
if(!isset($_SESSION["user"]) || $_SESSION["user"]["role"] != "LIBRARIAN"){
    echo "<script>alert('Access denied'); location.href='index.php';</script>";
    exit();
}

// Get user ID from URL
$user_id = $_GET['id'] ?? null;
if(!$user_id){
    die("User ID is required.");
}

// Fetch user data
$result = $conn->query("SELECT * FROM users WHERE user_id = $user_id");
if($result->num_rows == 0){
    die("User not found.");
}
$user = $result->fetch_assoc();

// Handle form submission
if(isset($_POST['update'])){
    $fullname = $conn->real_escape_string($_POST['fullname']);
    $email    = $conn->real_escape_string($_POST['username']);
    $role     = $_POST['role'];

    $update = "UPDATE users SET fullname='$fullname', username='$email', role='$role' WHERE user_id=$user_id";

    if($conn->query($update)){
        echo "<script>alert('User updated successfully'); location.href='manage_users.php';</script>";
        exit();
    } else {
        $error = "Error: " . $conn->error;
    }
}
?>



<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-6">

            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Update User</h4>
                </div>
                <div class="card-body">

                    <?php if(isset($error)): ?>
                        <div class="alert alert-danger"><?= $error ?></div>
                    <?php endif; ?>

                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="fullname" class="form-control" value="<?= htmlspecialchars($user['fullname']) ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">username</label>
                            <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($user['username']) ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Role</label>
                            <select name="role" class="form-select" required>
                                <option value="ADMIN" <?= $user['role']=='ADMIN' ? 'selected':'' ?>>ADMIN</option>
                                <option value="LIBRARIAN" <?= $user['role']=='LIBRARIAN' ? 'selected':'' ?>>LIBRARIAN</option>
                                <option value="MEMBER" <?= $user['role']=='MEMBER' ? 'selected':'' ?>>MEMBER</option>
                                <option value="GUEST" <?= $user['role']=='GUEST' ? 'selected':'' ?>>GUEST</option>
                            </select>
                        </div>

                        <div class="d-flex justify-content-between">
                            <a href="manage_users.php" class="btn btn-secondary">Back</a>
                            <button type="submit" name="update" class="btn btn-primary">Update User</button>
                        </div>
                    </form>

                </div>
            </div>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
