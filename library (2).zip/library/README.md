
# Readme

Credentials for accessing the application:

- Username: `librarian`  
- Password: `123`  

- Username: `student`  
- Password: `1234`

- Username: `staff`  
- Password: `12345`

- Username: `student two`  
- Password: `abc`
