<?php
function getdata($query){
global $conn;
$data=mysqli_query($conn,$query);
return mysqli_fetch_all($data,MYSQLI_ASSOC);
}
function saveData($query){
    global $conn;
    $sql = mysqli_query($conn,$query);
    if($sql){
        return true;
    }else{
        return die("Failed to connect");
    }
}