
<?php
$conn= mysqli_connect("localhost","root","","library");
if(!$conn){
    die("connedction failed".mysqli_connect_err());
}
?>