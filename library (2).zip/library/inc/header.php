<?php
session_start();
require_once("inc/conn.php");
require_once("inc/utils.php");

if(!isset($_SESSION["user"])){
    echo "<script>alert('You must login first'); location.href='index.php';</script>";
    exit();
}

$pending_count = 0;
$overdue_count = 0;

if($_SESSION["user"]["role"] == "LIBRARIAN"){
    $pending = getdata("SELECT COUNT(*) AS c FROM borrowed WHERE status='PENDING'");
    $pending_count = $pending[0]['c'];

    $today = date('Y-m-d H:i:s');
    $overdue = getdata("SELECT COUNT(*) AS c FROM borrowed WHERE status='APPROVED' AND date_to_return<'$today'");
    $overdue_count = $overdue[0]['c'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Library Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

<style>
body {
    min-height: 100vh;
}
.sidebar {
    height: 100vh;
    position: fixed;
    width: 250px;
    background: #0d6efd;
    padding-top: 20px;
}
.sidebar a {
    color: white;
    display: flex;
    align-items: center;
    padding: 12px 20px;
    text-decoration: none;
    margin-bottom: 5px;
    border-radius: 6px;
    transition: 0.3s;
}
.sidebar a:hover {
    background: #0b5ed7;
}
.sidebar i {
    margin-right: 10px;
    font-size: 18px;
}
.content {
    margin-left: 270px;
    padding: 20px;
}
.badge {
    margin-left: auto;
}
</style>
</head>
<body>

<div class="sidebar d-flex flex-column">

    <?php if ($_SESSION["user"]["role"] == "LIBRARIAN"): ?>
        <a href="books.php"><i class="bi bi-book"></i> Books</a>
        <a href="add_book.php"><i class="bi bi-plus-circle"></i> Add Book</a>
        <a href="borrowed_books.php"><i class="bi bi-journal-check"></i> Borrowed</a>
        <a href="manage_users.php"><i class="bi bi-people"></i> Members</a>
        <a href="report.php"><i class="bi bi-book"></i> Daily Report</a>
        <a href="notifications.php">
            <i class="bi bi-bell"></i> Notifications
            <?php if($pending_count + $overdue_count > 0): ?>
                <span class="badge bg-danger"><?= $pending_count + $overdue_count ?></span>
            <?php endif; ?>
        </a>
    <?php endif; ?>

    <?php if ($_SESSION["user"]["role"] == "MEMBER"): ?>
        <a href="library.php"><i class="bi bi-book"></i> Library</a>
        <a href="borrow_history.php"><i class="bi bi-clock-history"></i> My Borrow History</a>
        <a href="member_notification.php">
            <i class="bi bi-bell"></i> Notifications
            <a href="change_password.php"><i class="bi bi-key"></i> Change Password</a>
    <?php endif; ?>
    
    <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
</div>

<!-- Main content -->
<div class="content">
