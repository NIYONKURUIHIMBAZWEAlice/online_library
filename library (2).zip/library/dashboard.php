<?php
require_once("inc/conn.php");
require_once("inc/utils.php");
require_once("inc/header.php");

if (!isset($_SESSION['user']['user_id'])) {
    header("Location: login.php");
    exit;
}

$total_books = getdata("SELECT COUNT(*) AS total FROM book")[0]['total'];
$total_borrowed = getdata("SELECT COUNT(*) AS total FROM borrowed WHERE status='APPROVED'")[0]['total'];
$total_pending = getdata("SELECT COUNT(*) AS total FROM borrowed WHERE status='PENDING'")[0]['total'];
$total_users = getdata("SELECT COUNT(*) AS total FROM users")[0]['total'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <h2 class="mb-4">Library Dashboard</h2>

    <div class="row">

        <div class="col-md-3">
            <div class="card text-center p-3 shadow-sm">
                <h4>Total Books</h4>
                <p class="display-6"><?= $total_books ?></p>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-center p-3 shadow-sm">
                <h4>Borrowed</h4>
                <p class="display-6"><?= $total_borrowed ?></p>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-center p-3 shadow-sm">
                <h4>Pending</h4>
                <p class="display-6 text-warning"><?= $total_pending ?></p>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-center p-3 shadow-sm">
                <h4>Users</h4>
                <p class="display-6"><?= $total_users ?></p>
            </div>
        </div>

    </div>

    <hr class="my-4">

    <div class="list-group">
        <a href="library.php" class="list-group-item list-group-item-action">📚 View Books</a>
        <a href="add_book.php" class="list-group-item list-group-item-action">➕ Add New Book</a>
         <a href="logout.php" class="list-group-item list-group-item-action text-danger">🚪 Logout</a>
    </div>

</div>

</body>
</html>
