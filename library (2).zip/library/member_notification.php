<?php
require_once("inc/conn.php");
require_once("inc/utils.php");
include "inc/header.php";

if(!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'MEMBER'){
    echo "<script>alert('Access denied. Please login first.'); location.href='index.php';</script>";
    exit();
}

$user_id = $_SESSION['user']['user_id'];
$notifications = $_SESSION['member_notifications'] ?? [];
unset($_SESSION['member_notifications']); 

$borrow_status = getdata("
    SELECT b.title, br.status, br.date_borrowed
    FROM borrowed br
    INNER JOIN book b ON br.book_id = b.id
    WHERE br.user_id = $user_id AND br.status IN ('APPROVED','REJECTED')
    ORDER BY br.date_borrowed DESC
");

foreach($borrow_status as $item){
    if($item['status'] === 'APPROVED'){
        $notifications[] = "Your borrow request for '{$item['title']}' was APPROVED on {$item['date_borrowed']}.";
    } elseif($item['status'] === 'REJECTED'){
        $notifications[] = "Your borrow request for '{$item['title']}' was REJECTED on {$item['date_borrowed']}.";
    }
}

$today = date("Y-m-d");
$overdue_books = getdata("
    SELECT b.title, br.date_to_return
    FROM borrowed br
    INNER JOIN book b ON br.book_id = b.id
    WHERE br.user_id = $user_id
      AND br.status = 'APPROVED'
      AND br.date_to_return < '$today'
    ORDER BY br.date_to_return ASC
");

foreach($overdue_books as $book){
    $days_overdue = floor((strtotime($today) - strtotime($book['date_to_return'])) / 86400);
    $fine = $days_overdue * 500; 
    $notifications[] = "Book '{$book['title']}' is overdue by $days_overdue day(s). Fine: {$fine} RWF.";
}
?>

<div class="container mt-5">
    <h2>My Notifications</h2>
    <a href="library.php" class="btn btn-primary mb-3">Back to Library</a>

    <?php if(!empty($notifications)): ?>
        <div class="d-flex flex-column gap-3">
            <?php foreach($notifications as $note): ?>
                <div class="alert alert-info shadow-sm">
                    <?= htmlspecialchars($note) ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p class="text-muted">You have no notifications.</p>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
