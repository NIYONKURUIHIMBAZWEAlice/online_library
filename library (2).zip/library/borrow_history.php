<?php
require_once("inc/conn.php");
require_once("inc/utils.php");
include "inc/header.php"; 

if (!isset($_SESSION['user']['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user']['user_id'];

$history = getdata("
    SELECT b.id, b.title, b.author, br.date_borrowed, br.date_to_return AS return_date, br.status
   ,br.fine FROM borrowed br
    INNER JOIN book b ON br.book_id = b.id
    WHERE br.user_id = $user_id
    ORDER BY br.date_borrowed DESC
");
?>
<div class="container mt-5">
    <h2>My Borrow History</h2>
    <a href="library.php" class="btn btn-primary mb-3">Back to Library</a>

    <?php if (!empty($history)): ?>
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Date Borrowed</th>
                    <th>Return Date</th>
                    <th>Status</th>
                    <th>Fine</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($history as $index => $item): ?>

                    <?php
                       
                        $fine = 0;
                        $today = date("Y-m-d");

                        if ($item['return_date'] < $today && $item['status'] != "RETURNED") {
                            $days_overdue = (strtotime($today) - strtotime($item['return_date'])) / 86400;
                            $fine = $days_overdue * 500; 
                        }
                        if($item['status']=="RETURNED"){
                            $fine=$item['fine']??0;
                        }
                    ?>

                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td><?= htmlspecialchars($item['title']) ?></td>
                        <td><?= htmlspecialchars($item['author']) ?></td>
                        <td><?= htmlspecialchars($item['date_borrowed']) ?></td>
                        <td><?= htmlspecialchars($item['return_date']) ?></td>

                        <td>
                            <?php if ($item['status'] == "PENDING"): ?>
                                <span class="badge bg-warning text-dark">Pending</span>
                            <?php elseif ($item['status'] == "APPROVED"): ?>
                                <span class="badge bg-primary">Approved</span>
                            <?php elseif ($item['status'] == "REJECTED"): ?>
                                <span class="badge bg-danger">Rejected</span>
                            <?php elseif ($item['status'] == "RETURNED"): ?>
                                <span class="badge bg-success">Returned</span>
                            <?php endif; ?>
                        </td>

                        <td>
                            <?= $fine > 0 ? "<span class='text-danger fw-bold'>".$fine." RWF</span>" : "0 RWF" ?>
                        </td>
                    </tr>

                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="text-muted">You have not borrowed any books yet.</p>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
