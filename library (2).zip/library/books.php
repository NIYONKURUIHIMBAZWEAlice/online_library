<?php
require_once("inc/conn.php");
require_once("inc/utils.php");

$page = $_GET['page'] ?? 1;
$limit = 50;
$start = ($page - 1) * $limit;

$books = getdata("SELECT * FROM book ORDER BY id DESC LIMIT $start, $limit");

$total_books = getdata("SELECT COUNT(*) AS count FROM book");
$total_pages = ceil($total_books[0]['count'] / $limit);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Browsing History</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">      
</head>
<body>
    <?php include "inc/header.php"; ?>
    <div class="container mt-5">

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Book List</h2>
            <a href="add_book.php" class="btn btn-primary">Add Book</a>
        </div>

        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Image</th>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Quantity</th>
                    <th>Published Year</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($books as $book): ?>
                <tr>
                    <td><?= htmlspecialchars($book['id']); ?></td>

                    <td>
                        <?php if (!empty($book['image'])): ?>
                            <img src="<?= htmlspecialchars($book['image']); ?>" 
                                 style="width: 60px; height: 60px; object-fit: cover; border-radius: 5px;">
                        <?php else: ?>
                            <span class="text-muted">No Image</span>
                        <?php endif; ?>
                    </td>

                    <td><?= htmlspecialchars($book['title']); ?></td>
                    <td><?= htmlspecialchars($book['author']); ?></td>
                    <td><?= htmlspecialchars($book['quantity']); ?></td>
                    <td><?= htmlspecialchars($book['published_year']); ?></td>

                    <td>
                        <a href="update_book.php?id=<?= $book['id']; ?>" class="btn btn-warning btn-sm">Update</a>

                        <a href="delete_book.php?id=<?= $book['id']; ?>" 
                           class="btn btn-danger btn-sm"
                           onclick="return confirm('Are you sure you want to delete this book?');">
                           Delete
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <nav>
            <ul class="pagination">
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                        <a class="page-link" href="brow_history.php?page=<?= $i; ?>"><?= $i; ?></a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
