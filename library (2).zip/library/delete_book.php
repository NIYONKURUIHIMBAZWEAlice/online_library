<?php
require_once("inc/conn.php");
require_once("inc/utils.php");
if (!isset($_GET['id'])) {
    die("Invalid request.");
}

$book_id = intval($_GET['id']);

$book = getdata("SELECT * FROM book WHERE id = $book_id");

if (!$book) {
    die("Book not found.");
}

$book = $book[0];

if (!empty($book['image']) && file_exists($book['image'])) {
    unlink($book['image']);
}

$sql = "DELETE FROM book WHERE id = $book_id";
saveData($sql);

header("Location: books.php?");
exit;
?>
