<?php
include "inc/header.php";
require_once("inc/conn.php");
require_once("inc/utils.php");

$search = $_GET['search'] ?? '';
$search_sql = $search ? "WHERE title LIKE '%$search%' OR author LIKE '%$search%'" : "";

$page = $_GET['page'] ?? 1;
$limit = 4; 
$start = ($page - 1) * $limit;

$books = getdata("SELECT * FROM book $search_sql ORDER BY id DESC LIMIT $start, $limit");

$total_books_result = getdata("SELECT COUNT(*) AS count FROM book $search_sql");
$total_books = $total_books_result[0]['count'];
$total_pages = ceil($total_books / $limit);
?>

<div class="container mt-5">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Library</h2>
    </div>

    <form method="get" class="mb-4">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Search by title or author" value="<?= htmlspecialchars($search) ?>">
            <button class="btn btn-outline-secondary" type="submit">Search</button>
        </div>
    </form>

    <div class="row">
        <?php if (!empty($books)): ?>
            <?php foreach($books as $book): ?>
                <div class="col-md-3 mb-4">
                    <div class="card book-card h-100">
                        <?php if (!empty($book['image'])): ?>
                            <img src="<?= htmlspecialchars($book['image']); ?>" class="card-img-top" alt="<?= htmlspecialchars($book['title']); ?>">
                        <?php else: ?>
                            <div class="d-flex align-items-center justify-content-center bg-light" style="height:200px;">
                                <span class="text-muted">No Image</span>
                            </div>
                        <?php endif; ?>
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title"><?= htmlspecialchars($book['title']); ?></h5>
                            <p class="card-text mb-2">
                                <strong>Author:</strong> <?= htmlspecialchars($book['author']); ?><br>
                                <strong>Quantity:</strong> <?= htmlspecialchars($book['quantity']); ?><br>
                                <strong>Year:</strong> <?= htmlspecialchars($book['published_year']); ?>
                            </p>
                            <?php 
                            if ($book['quantity'] <= 0):
                                ?>

<span class="badge bg-danger mb-2">Out of Stock</span>
                            <?php
                            endif;
                            if ($book['quantity'] > 0 && $_SESSION['user']['role']=="MEMBER"): ?>
                            <a href="borrow_book.php?book_id=<?= $book['id']; ?>" class="btn btn-success mt-auto <?= $book['quantity'] <= 0 ? 'disabled' : '' ?>">
                                Borrow
                            </a>
                            <?php endif ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="text-muted">No books found.</p>
        <?php endif; ?>
    </div>
    <nav>
        <ul class="pagination justify-content-center">
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                    <a class="page-link" href="library.php?page=<?= $i ?>&search=<?= urlencode($search) ?>"><?= $i ?></a>
                </li>
            <?php endfor; ?>
        </ul>
    </nav>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
