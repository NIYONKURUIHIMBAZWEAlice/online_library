<?php
require_once("inc/conn.php");  // your DB connection
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>guest - Signup</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex justify-content-center align-items-center min-vh-100">

  <div class="col-md-5">
    <div class="card shadow-lg border-0">
      <div class="card-header bg-primary text-white text-center">
        <h4 class="mb-0">Signup</h4>
      </div>

      <div class="card-body">
        <form method="post" novalidate>

          <div class="mb-3">
            <label class="form-label">Full Name</label>
            <input type="text" name="fullname" class="form-control" required>
          </div>

          <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" name="username" class="form-control" required>
          </div>

          <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" required>
          </div>

          <div class="mb-3">
            <label class="form-label">Confirm Password</label>
            <input type="password" name="confirmpassword" class="form-control" required>
          </div>

          <button type="submit" name="signup" class="btn btn-success w-100">Sign Up</button>
        </form>
      </div>

      <div class="card-footer text-center">
        <small>Already have an account? <a href="index.php">Login here</a></small>
      </div>

    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php

if (isset($_POST['signup'])) {

    $fullname  = trim($_POST['fullname']);
    $username  = trim($_POST['username']);
    $password  = $_POST['password'];
    $cpassword = $_POST['confirmpassword'];

    // BASIC VALIDATION — No regex
    if (empty($password)) {
        echo "<script>alert('Password cannot be empty');</script>";
    }
    elseif ($password !== $cpassword) {
        echo "<script>alert('Passwords do not match');</script>";
    }
    else {

        // Hash password
        $hashed = password_hash($password, PASSWORD_DEFAULT);

        // Insert user
        $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        
        if ($stmt === false) {
            error_log("Prepare failed: " . $conn->error);
            echo "<script>alert('Something went wrong. Please try again.');</script>";
        } 
        else {
            $stmt->bind_param("ss", $username, $hashed);

            if ($stmt->execute()) {
                echo "<script>alert('Registration successful! Please login.'); 
                      window.location='index.php';</script>";
                exit();
            } 
            else {
                echo "<script>alert('Registration failed. Maybe username already exists.');</script>";
            }

            $stmt->close();
        }
    }
}
?>
