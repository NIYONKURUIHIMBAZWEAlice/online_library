<?php
require_once("inc/conn.php");
require_once("inc/utils.php");
include "inc/header.php";

if (!isset($_SESSION['user']['user_id'])) {
    header("Location: login.php");
    exit;
}

$start_date = $_GET['start_date'] ?? "";
$end_date   = $_GET['end_date'] ?? "";

$date_condition = "";

if (!empty($start_date) && !empty($end_date)) {
    $date_condition = "WHERE date_borrowed BETWEEN '$start_date' AND '$end_date'";
} elseif (!empty($start_date)) {
    $date_condition = "WHERE date_borrowed >= '$start_date'";
} elseif (!empty($end_date)) {
    $date_condition = "WHERE date_borrowed <= '$end_date'";
}

$total_books = getdata("SELECT COUNT(*) AS total FROM book")[0]['total'];
$total_borrowed = getdata("SELECT COUNT(*) AS total FROM borrowed WHERE status='APPROVED'")[0]['total'];
$total_pending  = getdata("SELECT COUNT(*) AS total FROM borrowed WHERE status='PENDING'")[0]['total'];
$total_returned = getdata("SELECT COUNT(*) AS total FROM borrowed WHERE status='RETURNED'")[0]['total'];

$fine_records = getdata("SELECT date_to_return, status FROM borrowed");
$total_fines = 0;
$today = date("Y-m-d");

foreach ($fine_records as $rec) {
    if ($rec['date_to_return'] < $today && $rec['status'] != "RETURNED") {
        $days = (strtotime($today) - strtotime($rec['date_to_return'])) / 86400;
        $total_fines += ($days * 500);
    }
}


$report_data = getdata("
    SELECT 
        br.id,
        u.fullname,
        b.title,
        b.author,
        br.date_borrowed,
        br.date_to_return,
        br.status
    FROM borrowed br
    INNER JOIN users u ON br.user_id = u.user_id
    INNER JOIN book b ON br.book_id = b.id
    $date_condition
    ORDER BY br.date_borrowed DESC
");

?>
<div class="container mt-5">

    <h2 class="mb-3">Library Report</h2>
    <a href="dashboard.php" class="btn btn-primary mb-3">Back to Dashboard</a>

    <form class="card p-3 mb-4 shadow-sm" method="GET" action="report.php">
        <div class="row">
            <div class="col-md-4">
                <label class="form-label">Start Date</label>
                <input type="date" name="start_date" value="<?= $start_date ?>" class="form-control">
            </div>

            <div class="col-md-4">
                <label class="form-label">End Date</label>
                <input type="date" name="end_date" value="<?= $end_date ?>" class="form-control">
            </div>

            <div class="col-md-4 d-flex align-items-end">
                <button class="btn btn-success me-2">Filter</button>

                <a href="report.php" class="btn btn-secondary">Clear</a>
            </div>
        </div>
    </form>

    <div class="row mb-4">

        <div class="col-md-3">
            <div class="card p-3 text-center shadow-sm">
                <h5>Total Books</h5>
                <p class="display-6"><?= $total_books ?></p>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card p-3 text-center shadow-sm">
                <h5>Borrowed</h5>
                <p class="display-6"><?= $total_borrowed ?></p>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card p-3 text-center shadow-sm">
                <h5>Pending</h5>
                <p class="display-6 text-warning"><?= $total_pending ?></p>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card p-3 text-center shadow-sm">
                <h5>Returned</h5>
                <p class="display-6 text-success"><?= $total_returned ?></p>
            </div>
        </div>

    </div>

    <div class="card p-3 mb-4 shadow-sm">
        <h5>Total Fines (Estimated)</h5>
        <p class="fs-3 text-danger"><?= number_format($total_fines) ?> RWF</p>
    </div>

    <h4>Borrowing Details</h4>
    <div class="table-responsive">
        <table class="table table-bordered table-striped mt-3">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>User</th>
                    <th>Book Title</th>
                    <th>Author</th>
                    <th>Date Borrowed</th>
                    <th>Return Date</th>
                     <th>Status</th>
                </tr>
            </thead>
            <tbody>

                <?php foreach ($report_data as $i => $row): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td><?= htmlspecialchars($row['fullname']) ?></td>
                        <td><?= htmlspecialchars($row['title']) ?></td>
                        <td><?= htmlspecialchars($row['author']) ?></td>
                        <td><?= htmlspecialchars($row['date_borrowed']) ?></td>
                        <td><?= htmlspecialchars($row['date_to_return']) ?></td>

                        <td>
                            <?php if ($row['status'] == "PENDING"): ?>
                                <span class="badge bg-warning text-dark">Pending</span>
                            <?php elseif ($row['status'] == "APPROVED"): ?>
                                <span class="badge bg-primary">Approved</span>
                            <?php elseif ($row['status'] == "RETURNED"): ?>
                                <span class="badge bg-success">Returned</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Rejected</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>

            </tbody>
        </table>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
