<?php
include "inc/header.php";
require_once("inc/conn.php");
require_once("inc/utils.php");

// Only allow logged-in members to view private books
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'GUEST') {
    echo "<script>alert('Access denied. Please login to view private books.'); location.href='index.php';</script>";
    exit();
}

// Search
$search = $_GET['search'] ?? '';
$search_sql = $search ? "AND (title LIKE '%$search%' OR author LIKE '%$search%')" : "";

// Pagination
$page = $_GET['page'] ?? 1;
$limit = 12; 
$start = ($page - 1) * $limit;

// Fetch only private books
$books = getdata("SELECT * FROM book WHERE privacy='private' $search_sql ORDER BY id DESC LIMIT $start, $limit");

// Count total private books for pagination
$total_books_result = getdata("SELECT COUNT(*) AS count FROM book WHERE privacy='private' $search_sql");
$total_books = $total_books_result[0]['count'];
$total_pages = ceil($total_books / $limit);
?>

<div class="container mt-5">
    <h2>Private Library (Guests Only)</h2>

    <!-- Search form -->
    <form method="get" class="mb-4">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Search by title or author" value="<?= htmlspecialchars($search) ?>">
            <button class="btn btn-outline-secondary" type="submit">Search</button>
        </div>
    </form>

    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 g-4">
        <?php if (!empty($books)): ?>
            <?php foreach($books as $book): ?>
                <div class="col">
                    <div class="card h-100">
                        <?php if (!empty($book['image'])): ?>
                            <img src="<?= htmlspecialchars($book['image']); ?>" class="card-img-top" alt="<?= htmlspecialchars($book['title']); ?>" style="height:200px; object-fit:cover;">
                        <?php else: ?>
                            <div class="d-flex align-items-center justify-content-center bg-light" style="height:200px;">
                                <span class="text-muted">No Image</span>
                            </div>
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($book['title']); ?></h5>
                            <p class="card-text mb-2">
                                <strong>Author:</strong> <?= htmlspecialchars($book['author']); ?><br>
                                <strong>Quantity:</strong> <?= htmlspecialchars($book['quantity']); ?><br>
                                <strong>Year:</strong> <?= htmlspecialchars($book['published_year']); ?>
                            </p>
                            <?php if ($book['quantity'] <= 0): ?>
                                <span class="badge bg-danger">Out of Stock</span>
                            <?php else: ?>
                                <span class="badge bg-info">Available</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="text-muted">No private books found.</p>
        <?php endif; ?>
    </div>

    <!-- Pagination -->
    <nav class="mt-4">
        <ul class="pagination justify-content-center">
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                    <a class="page-link" href="private_books.php?page=<?= $i ?>&search=<?= urlencode($search) ?>"><?= $i ?></a>
                </li>
            <?php endfor; ?>
        </ul>
    </nav>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
