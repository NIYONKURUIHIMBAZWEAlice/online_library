<?php
require_once("inc/conn.php");
require_once("inc/utils.php");
include "inc/header.php";

// Check if ID is provided
if (!isset($_GET['id'])) {
    die("Invalid request.");
}

$book_id = intval($_GET['id']);

// Fetch the book
$book = getdata("SELECT * FROM book WHERE id = $book_id");
if (!$book) {
    die("Book not found.");
}
$book = $book[0];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $author = trim($_POST['author']);
    $quantity = intval($_POST['quantity']);
    $published_year = intval($_POST['published_year']);

    // Handle image upload
    $image_path = $book['image']; // keep existing image by default
    if (!empty($_FILES['image']['name'])) {
        $upload_dir = "uploads/";
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

        $file_name = time() . "_" . basename($_FILES['image']['name']);
        $target_file = $upload_dir . $file_name;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            // delete old image
            if (!empty($book['image']) && file_exists($book['image'])) {
                unlink($book['image']);
            }
            $image_path = $target_file;
        } else {
            $error = "Failed to upload image.";
        }
    }

    // Update the database
    $sql = "UPDATE book SET title='$title', author='$author', quantity='$quantity', published_year='$published_year', image='$image_path' WHERE id=$book_id";
    saveData($sql);

    header("Location: books.php?msg=Book updated successfully");
    exit;
}
?>

<div class="container mt-5">
    <h2>Update Book</h2>
    <a href="brow_history.php" class="btn btn-secondary mb-3">Back to Book List</a>

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data" class="card p-4 shadow-sm">
        <div class="mb-3">
            <label class="form-label">Title</label>
            <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($book['title']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Author</label>
            <input type="text" name="author" class="form-control" value="<?= htmlspecialchars($book['author']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Quantity</label>
            <input type="number" name="quantity" class="form-control" value="<?= htmlspecialchars($book['quantity']) ?>" min="0" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Published Year</label>
            <input type="number" name="published_year" class="form-control" value="<?= htmlspecialchars($book['published_year']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Current Image</label><br>
            <?php if (!empty($book['image'])): ?>
                <img src="<?= htmlspecialchars($book['image']) ?>" style="width:100px; height:100px; object-fit:cover; border-radius:5px;">
            <?php else: ?>
                <span class="text-muted">No image</span>
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <label class="form-label">Change Image (optional)</label>
            <input type="file" name="image" class="form-control">
        </div>

        <button type="submit" class="btn btn-success">Update Book</button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
