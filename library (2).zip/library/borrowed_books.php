<?php
include_once("inc/header.php");
require_once("inc/conn.php");
require_once("inc/utils.php");

if (!isset($_SESSION['user']['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user']['user_id'];

$history = getdata("
    SELECT br.id AS borrow_id, b.title, u.fullname,br.fine, b.author, br.date_borrowed, br.date_to_return AS return_date, br.status
    FROM borrowed br
    INNER JOIN book b ON br.book_id = b.id
    INNER JOIN users u ON br.user_id = u.user_id
    ORDER BY br.date_borrowed DESC
");
?>
<div class="container mt-5">
    <h2>My Borrow History</h2>
    <a href="library.php" class="btn btn-primary mb-3">Back to Library</a>

    <?php if (!empty($history)): ?>
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Date Borrowed</th>
                    <th>Borrowed By</th>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Return Date</th>
                    <th>Fine</th>
                    <th>Status / Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($history as $index => $item):
                    $fine = 0;
                    if ($item['status'] === 'APPROVED') {
                        $due_date = $item['return_date'];
                        $days_late = (strtotime(date('Y-m-d H:i:s')) - strtotime($due_date)) / 86400;
                        if ($days_late > 0) {
                            $fine = $days_late * 200;
                        }
                    }elseif($item['status'] === 'RETURNED'){
                       $fine=$item['fine']??0;
                    }
                    ?>
                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td><?= htmlspecialchars($item['date_borrowed']) ?></td>
                        <td><?= htmlspecialchars($item['fullname']) ?></td>
                        <td><?= htmlspecialchars($item['title']) ?></td>
                        <td><?= htmlspecialchars($item['author']) ?></td>
                        <td><?= htmlspecialchars($item['return_date']) ?></td>
                        <td><?= $fine > 0 ? htmlspecialchars($fine) . ' RWF' : 'No Fine' ?></td>
                        <td>
                            <?php if ($item['status'] === 'PENDING'): ?>
                                <a href="update_borrow.php?id=<?= $item['borrow_id'] ?>&action=approve" class="btn btn-success btn-sm">Confirm</a>
                                <a href="update_borrow.php?id=<?= $item['borrow_id'] ?>&action=reject" class="btn btn-danger btn-sm">Reject</a>
                            <?php elseif ($item['status'] === 'APPROVED'): ?>
                                <a href="update_borrow.php?id=<?= $item['borrow_id'] ?>&action=return" class="btn btn-warning btn-sm">Record Return</a>
                            <?php else: ?>
                                <span class="badge bg-secondary"><?= htmlspecialchars($item['status']) ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="text-muted">You have no borrow records yet.</p>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
