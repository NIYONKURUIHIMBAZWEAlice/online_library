<?php
session_start();
require_once("inc/conn.php");
require_once("inc/utils.php");

// Access control
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'LIBRARIAN') {
    die("Access denied.");
}

$borrow_id = $_GET['id'] ?? null;
$action = $_GET['action'] ?? null;

if (!$borrow_id || !$action) {
    die("Invalid request.");
}

// Fetch borrow record
$borrow = getdata("SELECT * FROM borrowed WHERE id = $borrow_id");
if (!$borrow) {
    die("Borrow record not found.");
}

$borrow = $borrow[0];
$book_id = $borrow['book_id'];

$loan_days = 7;     
$fine_per_day = 200; 

switch ($action) {

    // ----------------------------------------
    // ✔️ APPROVE ACTION
    // ----------------------------------------
    case 'approve':
        if ($borrow['status'] === 'PENDING') {

            // Calculate due date
            $due_date = date('Y-m-d H:i:s', strtotime("+$loan_days days"));

            saveData("UPDATE borrowed 
                      SET status='APPROVED' 
                      WHERE id = $borrow_id");

            // Reduce book stock
            saveData("UPDATE book 
                      SET quantity = quantity - 1 
                      WHERE id = $book_id");
        }
        break;
    case 'reject':
        if ($borrow['status'] === 'PENDING') {
            saveData("UPDATE borrowed 
                      SET status='REJECTED' 
                      WHERE id = $borrow_id");
        }
        break;
    case 'return':
        if ($borrow['status'] === 'APPROVED') {

            $return_date = date('Y-m-d H:i:s');

            // Fine calculation
            $due_date = $borrow['date_to_return'];
            $days_late = (strtotime($return_date) - strtotime($due_date)) / 86400;

            $fine = 0;
            if ($days_late > 0) {
                $fine = ceil($days_late) * $fine_per_day;
            }

            saveData("UPDATE borrowed 
                      SET status='RETURNED', 
                          returned_date='$return_date',
                          fine=$fine 
                      WHERE id = $borrow_id");

            // Increase stock back
            saveData("UPDATE book 
                      SET quantity = quantity + 1 
                      WHERE id = $book_id");
        }
        break;

    default:
        die("Invalid action.");
}

// Redirect back
header("Location: borrowed_books.php");
exit;
?>
