<?php
require_once("inc/conn.php");
require_once("inc/utils.php");
require_once("inc/header.php");

if(!isset($_SESSION["user"])){
    echo "<script>alert('You must login first'); location.href='index.php';</script>";
    exit();
}

if(!in_array($_SESSION["user"]["role"], ['ADMIN','LIBRARIAN'])){
    echo "<script>alert('Access denied'); location.href='index.php';</script>";
    exit();
}

$pending = getdata("
    SELECT br.id, u.fullname, b.title, br.date_borrowed
    FROM borrowed br
    INNER JOIN users u ON br.user_id = u.user_id
    INNER JOIN book b ON br.book_id = b.id
    WHERE br.status = 'PENDING'
    ORDER BY br.date_borrowed DESC
");

$today = date('Y-m-d H:i:s');
$overdue = getdata("
    SELECT br.id, u.fullname, b.title, br.date_to_return AS due_date
    FROM borrowed br
    INNER JOIN users u ON br.user_id = u.user_id
    INNER JOIN book b ON br.book_id = b.id
    WHERE br.status = 'APPROVED' AND br.date_to_return < '$today'
    ORDER BY br.date_to_return ASC
");
?>
<div class="container my-5">
    <h2>System Notifications</h2>

    <h4 class="mt-4">Pending Borrow Requests</h4>
    <?php if(!empty($pending)): ?>
        <table class="table table-bordered">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Members Name</th>
                    <th>Book Title</th>
                    <th>Request Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($pending as $i => $p): ?>
                <tr>
                    <td><?= $i+1 ?></td>
                    <td><?= htmlspecialchars($p['fullname']) ?></td>
                    <td><?= htmlspecialchars($p['title']) ?></td>
                    <td><?= htmlspecialchars($p['date_borrowed']) ?></td>
                    <td>
                        <a href="update_borrow.php?id=<?= $p['id'] ?>&action=approve" class="btn btn-success btn-sm">Approve</a>
                        <a href="update_borrow.php?id=<?= $p['id'] ?>&action=reject" class="btn btn-danger btn-sm">Reject</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="text-muted">No pending requests.</p>
    <?php endif; ?>


    <!-- Overdue Books -->
    <h4 class="mt-5">Overdue Books</h4>
    <?php if(!empty($overdue)): ?>
        <table class="table table-bordered">
            <thead class="table-danger">
                <tr>
                    <th>#</th>
                    <th>Staff Name</th>
                    <th>Book Title</th>
                    <th>Due Date</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($overdue as $i => $o): ?>
                <tr>
                    <td><?= $i+1 ?></td>
                    <td><?= htmlspecialchars($o['fullname']) ?></td>
                    <td><?= htmlspecialchars($o['title']) ?></td>
                    <td><?= htmlspecialchars($o['due_date']) ?></td>
                    <td><span class="badge bg-danger">Overdue</span></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="text-muted">No overdue books.</p>
    <?php endif; ?>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
